package mesas;

public interface Figura {
    public Double calcularArea();

}
